#include "stm32f10x.h"
#include "led.h"
#include "bsp_usart.h"


int main(void)
{

  uint8_t ch;
	USART_Config() ;
	LED_GPIO_Config();
  printf( "����һ������ͨ�ſص�" );
	
	while(1){ 
		ch =getchar();
		printf("ch= %c\n",ch);
		
		switch(ch)
		{
					case '0':LED_RED;break;
			case '1':LED_BULE;break;
			default:LED_RGBOFF;break;
		
		
		
		}
     }
 }


