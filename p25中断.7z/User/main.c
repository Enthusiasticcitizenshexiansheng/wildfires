#include "stm32f10x.h"
#include "led.h"
#include "bsp_exti.h"
void Delay(uint32_t count)
{
for(;count!=0;count--);

}

int main(void)
{
   LED_GPIO_Config();
   EXTI_Key_Config();
while(1){ 
	
}
}


