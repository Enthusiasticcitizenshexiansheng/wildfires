#ifndef __BSP_EXTI_H__
#define __BSP_EXTI_H__

#include "stm32f10x.h"
#define KEY1_INT_GPIO_PIN       GPIO_Pin_3	
#define KEY1_INT_GPIO_PORT      GPIOE
#define KEY1_INT_GPIO_CLK       RCC_APB2Periph_GPIOE

void EXTI_Key_Config(void);
#endif