#include "stm32f10x.h"
#include "led.h"
#include "bsp_dma_mtm.h"
extern const uint32_t aSRC_Const_Buffer[BUFFER_SIZE];
extern uint32_t aDST_Buffer[BUFFER_SIZE];

#define SOFT_DELAY Delay(0x0FFFFF);
void Delay(__IO u32 nCount);


//�ȻƵ� ���̵� ���º��
int main(void)
{
	uint8_t status =0;
   LED_GPIO_Config();
	LED_BULE;
	Delay(0xFFFFFF);
	
	 MtM_DMA_Config();
  
	//�����Ƿ����
	while(DMA_GetFlagStatus(MTM_DMA_FLAG_TC)==RESET);
	
	status= Buffercmp(aSRC_Const_Buffer,aDST_Buffer,BUFFER_SIZE);
	
	if(status == 0)
	{
	LED_RED;
	}
	else
	{
		LED_BULE;
	}
		
	
	
while(1){ 

}
}
//��ʱ����
void Delay(uint32_t count)
{
for(;count!=0;count--);

}

