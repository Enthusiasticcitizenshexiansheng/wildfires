#ifndef __BSP_RCCLKCONFIG_H__
#define __BSP_RCCLKCONFIG_H__



#include "stm32f10x.h"

void HSE_SetSysClk(uint32_t RCC_PLLMul_x);
void MCO_GPIO_Config();

#endif