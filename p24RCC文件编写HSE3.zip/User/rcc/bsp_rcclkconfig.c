#include "bsp_rcclkconfig.h"

void HSE_SetSysClk(uint32_t RCC_PLLMul_x)
{

	ErrorStatus  HSEStatus;
		//RCC��λ
	RCC_DeInit();

	//ʹ��HSE
  RCC_HSEConfig(RCC_HSE_ON);

	HSEStatus = RCC_WaitForHSEStartUp();
	
	if(HSEStatus ==SUCCESS)	
	{
	//HSE�����ɹ�  ʹ��Ԥȡָ
	FLASH_PrefetchBufferCmd(FLASH_PrefetchBuffer_Enable);
	FLASH_SetLatency(FLASH_Latency_2);
		
		//���߷�Ƶ����
	 RCC_HCLKConfig(RCC_SYSCLK_Div1);
   RCC_PCLK1Config(RCC_HCLK_Div2);
   RCC_PCLK2Config(RCC_HCLK_Div1);
		
	
//���໷
 RCC_PLLConfig(RCC_PLLSource_HSE_Div1, RCC_PLLMul_x);
		//ʹ��
 RCC_PLLCmd(ENABLE);
		
	
		//�ȴ�PLL�ȶ�
	while	(RCC_GetFlagStatus(RCC_FLAG_PLLRDY)== RESET);
   

		//����ʱ��Դ
		RCC_SYSCLKConfig(RCC_SYSCLKSource_PLLCLK);
     while(RCC_GetSYSCLKSource()!=0x08) ;  //���ɹ�����
		 
		
		
		
		
		
		
	}
		else{		}

}




void MCO_GPIO_Config()
	
{
	//PC14 IN�� RCC1���н�
 GPIO_InitTypeDef GPIO_InitSture;
 RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOC, ENABLE);
 
	
 GPIO_InitSture.GPIO_Pin=	GPIO_Pin_14;
 GPIO_InitSture.GPIO_Mode=	GPIO_Mode_AF_PP;
 GPIO_InitSture.GPIO_Speed= GPIO_Speed_50MHz;
	
 GPIO_Init(GPIOC , &GPIO_InitSture);


}
