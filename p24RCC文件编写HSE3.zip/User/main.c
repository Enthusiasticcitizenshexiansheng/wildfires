#include "stm32f10x.h"
#include "led.h"
#include "bsp_rcclkconfig.h"

void Delay(uint32_t count)
{
for(;count!=0;count--);

}

int main(void)
{
	//ϵͳʱ��Ϊ72��
HSE_SetSysClk( RCC_PLLMul_9);
	
	 MCO_GPIO_Config();
	 RCC_MCOConfig(RCC_MCO_SYSCLK);  //ʹ��
	
	
   LED_GPIO_Config();
while(1){ 
	
  LED_G(OFF);
	Delay(0xFFFFF);
	
	
   LED_G(ON);
	Delay(0xFFFFF);

}
}


