#include "stm32f10x.h"
#include "led.h"
#include "bsp_dma_mtp.h"

extern uint8_t SendBuff[SENDBUFF_SIZE];

#define SOFT_DELAY Delay(0x0FFFFFF);
void Delay(__IO uint32_t nCount);
void Delay(__IO uint32_t nCount)
{
for(;nCount!=0;nCount--);

}

int main(void)
{
	
	uint16_t i=0;
   LED_GPIO_Config();
	USART_Config();//���ڳ�ʼ��
	
	for( i=0;i<SENDBUFF_SIZE;i++)
	{
	SendBuff[i]='P';
	}
	
   USARTx_DMA_Config();//DMA��ʼ�� 
   USART_DMACmd(DEBUG_USARTx,USART_DMAReq_Tx, ENABLE);//��������
while(1){ 
LED0_TOGGLE;
	Delay(0xFFFFFF);
	
}
}


