#ifndef __BSP_SPI_H_
#define __BSP_SPI_H_


#include "stm32f10x.h"
#include <stdio.h>

#include <stdlib.h>
#include "stm32f10x_i2c.h"
#define STM32_I2C_OWN_ADDR   0x5f

//FLASH �豸��ַ  д��ַ
#define FLASH_ADDR  0xA0
#define FLASH_SPI_BAUDRATE       400000
//PB6 -SCL        PB7-SDA





//spi ����
#define FLASH_SPIx                SPI2 
#define FLASH_SPI_APBxClock_FUN   RCC_APB1PeriphClockCmd
#define FLASH_SPI_CLK             RCC_APB1Periph_SPI2

//i2c GPIO���ź궨��  ʱ��ʹ�� ���ص�APB2��  �ܽ�
#define FLASH_SPI_GPIO_APBxClock_FUN   RCC_APB2PeriphClockCmd
#define FLASH_SPI_GPIO_CLK             RCC_APB2Periph_GPIOB        



//PB13-15            pa5-7
//SCK MI MO         SCK MI MO
#define FLASH_SPI_SCK_PORT        GPIOB
#define FLASH_SPI_SCK_PIN         GPIO_Pin_13

#define FLASH_SPI_MISO_PORT        GPIOB
#define FLASH_SPI_MISO_PIN         GPIO_Pin_14

#define FLASH_SPI_MOSI_PORT        GPIOB
#define FLASH_SPI_MOSI_PIN         GPIO_Pin_15

#define FLASH_SPI_CS_PORT        GPIOB
#define FLASH_SPI_CS_PIN         GPIO_Pin_12


//cs��������
#define FLASH_SPI_CS_HIGH  GPIO_SetBits(FLASH_SPI_CS_PORT,FLASH_SPI_CS_PIN );
#define FLASH_SPI_CS_LOW   GPIO_ResetBits(FLASH_SPI_CS_PORT,FLASH_SPI_CS_PIN );




//�ȴ���ʱʱ��
#define SPIT_FLAG_TIMEOUT    ((uint32_t)0x1000)
#define SPIT_LONG_TIMEOUT     ((uint32_t)(10*SPIT_FLAG_TIMEOUT))

//��Ϣ��� 
#define FLASH_DEBUG_ON   0

#define FLASH_INFO(fmt,arg...)     printf("<<-FLASH-INFO-"fmt"\n",##arg)
#define FLASH_ERROR(fmt,arg...)     printf("<<-FLASH-ERROR-"fmt"\n",##arg)
#define FLASH_DEBUG(fmt,arg...)     do{\
                                     if(FLASH_DEBUG_ON)\
                                     printf("<<-FLASH-DEBUG->> [%d]"fmt"\n",__LINE__,##arg);}while(0)

		
																		 
#define DUMMY          0x00																 
#define READ_JEDEC_ID  0x9f 
#define ERASE_SECTOR   0x20
#define READ_STATUS		 0x05  //��д״̬�Ĵ���
#define READ_DATA		   0x03  //2��ȡ����
#define WRITE_ENABLE   0x06
#define WRIYE_DATA     0x02  //������
																		 
void SPI_FLASH_Init(void);
uint32_t SPI_Read_ID(void);
void SPI_Erase_Sector(uint32_t addr);
void SPI_WaiteFowWriteEnd(void);		
	//��ȡһ���ֽ�																	 
void SPI_Read_Data(uint32_t addr,uint8_t *readBuff,uint32_t numByteToRead);																		 
void SPI_Write_Data(uint32_t addr,uint8_t *writeBuff,uint32_t numByteToWrite);
void SPI_Write_Enable(void);																 
#endif

