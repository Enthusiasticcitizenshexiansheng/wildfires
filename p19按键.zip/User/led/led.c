#include"led.h"

void LED_GPIO_Config(void)
{
 GPIO_InitTypeDef GPIO_InitSture;
 RCC_APB2PeriphClockCmd(LED_G_GPIO_CLK , ENABLE);
 
	
 GPIO_InitSture.GPIO_Pin=	LED_G_GPIO_PIN;
 GPIO_InitSture.GPIO_Mode=	GPIO_Mode_Out_PP;
 GPIO_InitSture.GPIO_Speed= GPIO_Speed_50MHz;
	
 GPIO_Init(LED_G_GPIO_PORT , &GPIO_InitSture);


}

