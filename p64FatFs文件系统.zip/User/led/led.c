#include"led.h"

void LED_GPIO_Config(void)
{
 GPIO_InitTypeDef GPIO_InitSture;
		 GPIO_InitTypeDef GPIO_InitStur;
 RCC_APB2PeriphClockCmd(LED0_GPIO_CLK , ENABLE);
 
	
 GPIO_InitSture.GPIO_Pin=	LED0_GPIO_PIN;
 GPIO_InitSture.GPIO_Mode=	GPIO_Mode_Out_PP;
 GPIO_InitSture.GPIO_Speed= GPIO_Speed_50MHz;
 GPIO_Init(LED0_GPIO_PORT , &GPIO_InitSture);


	
	
	
	
	
	

 RCC_APB2PeriphClockCmd(LED1_GPIO_CLK , ENABLE);
 
	
 GPIO_InitStur.GPIO_Pin=	LED1_GPIO_PIN;
 GPIO_InitStur.GPIO_Mode=	GPIO_Mode_Out_PP;
 GPIO_InitStur.GPIO_Speed= GPIO_Speed_50MHz;
 GPIO_Init(LED1_GPIO_PORT , &GPIO_InitStur);
}

