#include "stm32f10x.h"
#include "led.h"
#include "bsp_key.h"


//�� pe5 pb5
//λ����ʽ
#define GPIOE_ODR_Addr  (GPIOE_BASE+0x0C)
#define PEout(n)  *(unsigned int*)((GPIOE_ODR_Addr & 0xF0000000)+0x02000000+((GPIOE_ODR_Addr &0x00FFFFFF)<<5)+(n<<2))

//���� PE3-> 1   PE3-> 0��
#define GPIOE_IDR_Addr  (GPIOE_BASE+0x08)
#define PEin(n)  *(unsigned int*)(GPIOE_IDR_Addr & 0xF0000000)+0x02000000)+((GPIOE_IDR_Addr &0x00FFFFFF)<<5)+(n<<2))






void Delay(uint32_t count)
{
for(;count!=0;count--);

}

int main(void)
{
	
   LED_GPIO_Config();
   KEY_GPIO();

#if 1
	while(1){ 
	//GPIO_SetBits(LED_G_GPIO_PORT , LED_G_GPIO_PIN );
  //LED_G(OFF);
		PEout(5) = 1;
	Delay(0xFFFFF);
	
	 
	//GPIO_ResetBits(LED_G_GPIO_PORT , LED_G_GPIO_PIN );
  // LED_G(ON);
  PEout(5) = 0;
	Delay(0xFFFFF);
}
	



#else
	while(1){ 
      if( PEin(4)  == KEY_ON)
			{
				while(PEin(4)  == KEY_ON);
		  	LED_G_TOGGLE;
			}
			
			
			 if( PEin(3)  == KEY_ON)
			{
				while(PEin(3)  == KEY_ON);
		  	LED_G_TOGGLE;
			}
			
   }
	#endif
}


