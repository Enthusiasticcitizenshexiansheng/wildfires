#ifndef __DSP_KEY_H_
#define __DSP_KEY_H_

#include "stm32f10x.h"

//PE3 PE4  1 0
#define KEY1_GPIO_PIN       GPIO_Pin_3
#define KEY1_GPIO_PORT      GPIOE
#define KEY1_GPIO_CLK       RCC_APB2Periph_GPIOE

//Ϊʹ��idr=1 01�Ѿ���������
#define KEY_ON  0
#define KEY_OFF 1

#define KEY2_GPIO_PIN       GPIO_Pin_4
#define KEY2_GPIO_PORT      GPIOE
#define KEY2_GPIO_CLK       RCC_APB2Periph_GPIOE


void LED_GPIO_Config(void);




#define  LED_G_TOGGLE  { LED_G_GPIO_PORT->ODR ^= LED_G_GPIO_PIN;}



void KEY_GPIO(void);
uint8_t Key_Scan(GPIO_TypeDef *GPIOx,uint16_t GPIO_Pin);
#endif

